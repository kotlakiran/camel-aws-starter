# springboot-sqs-camel

This example gives details about integrating AMAZON SQS with apache camel. Just add a application-dev.properties and add
below properties and you are good to go:

sqs.accessKey=<<Access Key>>

sqs.secretKey=<<Secret Key>>

sqs.proxyhost=<<Proxy Host Name>>

sqs.proxyport=<<Proxy Port Name>>

sqs.queue=<<Queue Name>>
